
          <div class="section-body">
            <?php $this->load->view('frontend/user_member'); ?>
              <div class="col-md-8">
          <div class="row">
            <div class="col-lg-12 col-md-6 col-sm-6 col-12">
              <div class="row">
              <div class="col-sm-6">
                <div class="card">
                  <div class="card-body">
                    <h5 class="card-title">Hallo Farmer's</h5>
                    <p class="card-text">
                      Semoga harimu menyenangkan!</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
              </div>
            </div>
  		    </div>
      	</section>
      </div>
